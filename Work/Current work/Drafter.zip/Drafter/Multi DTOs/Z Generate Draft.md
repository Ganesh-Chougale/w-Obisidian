```md
paste everything Here
```

# Raw Data level
## Header module(H module)
- has own DTO, Interface & DAL

## Index module(I module)
- has own DTO, Interface & DAL but index module is sub part of Header module, which means one Brief row in Header will be multiple detailed row in Index module

# Processing level
- here we have common business for Header & Index module, we can implement individual module methods here or can implement combined modules methods like transaction scope etc.
- a common controller which gets what business sends it

we can also have supplimentary DTO, INTERFACE & DAL if needed so we have that flexibility too.  
so for now have this. i will tell what we need to do next.
