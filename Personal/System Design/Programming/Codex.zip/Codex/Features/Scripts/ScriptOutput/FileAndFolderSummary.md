```
Basics
├── 00 Index.md
├── 01 Starter.md
├── 02 Wikilinks.md
├── 03 Embeded Link.md
├── 04 Partial Embed.md
├── 05 Image In markdown.md
├── 06 Obsidian Callouts.md
└── 07 Tags.md
```